
          // Action Types
          export const SET_SIGNER_CONNECTION = "SET_SIGNER_CONNECTION";
          export const SET_SIGNER_INSTANCE = "SET_SIGNER_INSTANCE";
          export const SET_SIGNER_CHAIN_ID = "SET_SIGNER_CHAIN_ID";

          // Action Creators
          export const setSignerConnection = (isConnected) => ({
            type: SET_SIGNER_CONNECTION,
            payload: isConnected
          });

          export const setSignerInstance = (signer) => ({
            type: SET_SIGNER_INSTANCE,
            payload: signer
          });

          export const setSignerChainId = (chainId) => ({
            type: SET_SIGNER_CHAIN_ID,
            payload: chainId
          });

          // Thunk Action Creator for connecting signer
          export const connectSignerAction = (provider) => async (dispatch) => {
            try {
              const signer = provider.getSigner();
              dispatch(setSignerInstance(signer));
              dispatch(setSignerConnection(true));
              
              const network = await provider.getNetwork();
              dispatch(setSignerChainId(network.chainId));
            } catch (error) {
              console.error('Error connecting signer:', error);
            }
          };

          export const disconnectSignerAction = () => (dispatch) => {
            dispatch(setSignerInstance(null));
            dispatch(setSignerConnection(false));
            dispatch(setSignerChainId(null));
          };

          export const updateSignerChainIdAction = (chainId) => (dispatch) => {
            dispatch(setSignerChainId(chainId));
          };

          // Selectors
          export const getIsSignerConnected = (state) => state.signer.isConnected;
          export const getSignerInstance = (state) => state.signer.signer;
          export const getSignerChainId = (state) => state.signer.chainId;

          // Combined selector
          export const getSignerState = (state) => ({
            isConnected: getIsSignerConnected(state),
            signer: getSignerInstance(state),
            chainId: getSignerChainId(state)
          });

          const initialState = {
            isConnected: false,
            signer: null,
            chainId: null
          };

          export const signerReducer = (state = initialState, action) => {
            switch (action.type) {
              case SET_SIGNER_CONNECTION:
                return {
                  ...state,
                  isConnected: action.payload
                };
              case SET_SIGNER_INSTANCE:
                return {
                  ...state,
                  signer: action.payload
                };
              case SET_SIGNER_CHAIN_ID:
                return {
                  ...state,
                  chainId: action.payload
                };
              default:
                return state;
            }
          };