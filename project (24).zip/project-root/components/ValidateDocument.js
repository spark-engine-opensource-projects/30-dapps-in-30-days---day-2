'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function ValidateDocument() {
  const [documentHash, setDocumentHash] = React.useState('');
  const [isValid, setIsValid] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState('');
  const [animateResult, setAnimateResult] = React.useState(false);

  const validateDocument = async () => {
    if (!documentHash.trim()) {
      setError('Please enter a document hash');
      return;
    }
    
    setIsLoading(true);
    setError('');
    setIsValid(null);
    
    try {
      // Simulating contract call
      setTimeout(() => {
        // This would be replaced with actual contract call
        // const result = await contract.validateDocument(documentHash);
        const result = Math.random() > 0.5; // Simulating result
        setIsValid(result);
        setAnimateResult(true);
        setIsLoading(false);
        
        setTimeout(() => setAnimateResult(false), 500);
      }, 1500);
    } catch (err) {
      setError('Failed to validate document: ' + err.message);
      setIsLoading(false);
    }
  };

  return React.createElement(
    styled.div`
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background: linear-gradient(135deg, #f7f9fc 0%, #eef1f5 100%);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    `,
    null,
    React.createElement(
      styled.header`
        background-color: #ffffff;
        padding: 1.5rem 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        display: flex;
        justify-content: space-between;
        align-items: center;
        
        @media (max-width: 768px) {
          padding: 1.25rem 1.5rem;
          flex-direction: column;
          align-items: flex-start;
        }
      `,
      null,
      React.createElement(
        styled.div`
          display: flex;
          align-items: center;
        `,
        null,
        React.createElement(
          styled.div`
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background-color: #FFC107;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-right: 1rem;
          `,
          null,
          React.createElement(
            styled.span`
              color: #ffffff;
              font-weight: bold;
              font-size: 1.25rem;
            `,
            null,
            'TS'
          )
        ),
        React.createElement(
          styled.h1`
            font-size: 1.5rem;
            font-weight: 700;
            color: #333333;
            margin: 0;
            
            @media (max-width: 768px) {
              font-size: 1.25rem;
            }
          `,
          null,
          'Document Timestamping'
        )
      ),
      React.createElement(
        styled.nav`
          @media (max-width: 768px) {
            margin-top: 1rem;
            align-self: flex-end;
          }
        `,
        null,
        React.createElement(
          styled.a`
            color: #673AB7;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.5rem 0.75rem;
            border-radius: 4px;
            transition: all 0.2s ease;
            
            &:hover {
              background-color: #f0e6ff;
            }
            
            &:not(:last-child) {
              margin-right: 1rem;
            }
          `,
          { href: '#' },
          'Home'
        ),
        React.createElement(
          styled.a`
            color: #673AB7;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.5rem 0.75rem;
            border-radius: 4px;
            transition: all 0.2s ease;
            
            &:hover {
              background-color: #f0e6ff;
            }
            
            &:not(:last-child) {
              margin-right: 1rem;
            }
          `,
          { href: '#' },
          'Register Document'
        ),
        React.createElement(
          styled.a`
            color: #ffffff;
            background-color: #673AB7;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.5rem 0.75rem;
            border-radius: 4px;
            transition: all 0.2s ease;
            
            &:hover {
              background-color: #5e35b1;
              box-shadow: 0 2px 5px rgba(103, 58, 183, 0.3);
            }
          `,
          { href: '#' },
          'Verify Document'
        )
      )
    ),
    React.createElement(
      styled.main`
        flex: 1;
        padding: 3rem 2rem;
        max-width: 1200px;
        margin: 0 auto;
        width: 100%;
        
        @media (max-width: 768px) {
          padding: 2rem 1.5rem;
        }
      `,
      null,
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          margin-bottom: 3rem;
        `,
        null,
        React.createElement(
          styled.h2`
            font-size: 2.5rem;
            font-weight: 800;
            color: #333333;
            margin-bottom: 1rem;
            
            @media (max-width: 768px) {
              font-size: 2rem;
            }
          `,
          null,
          'Verify Document Authenticity'
        ),
        React.createElement(
          styled.p`
            font-size: 1.125rem;
            line-height: 1.6;
            color: #666666;
            max-width: 700px;
            
            @media (max-width: 768px) {
              font-size: 1rem;
            }
          `,
          null,
          'Confirm if your document has been timestamped on the blockchain. Enter the document hash to verify its authenticity and view timestamp information.'
        )
      ),
      React.createElement(
        styled.div`
          background-color: #ffffff;
          border-radius: 12px;
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
          padding: 2.5rem;
          width: 100%;
          max-width: 800px;
          margin: 0 auto;
          
          @media (max-width: 768px) {
            padding: 1.5rem;
          }
        `,
        null,
        React.createElement(
          styled.div`
            margin-bottom: 2.5rem;
          `,
          null,
          React.createElement(
            styled.h3`
              font-size: 1.25rem;
              font-weight: 700;
              color: #333333;
              margin-bottom: 0.5rem;
            `,
            null,
            'Enter Document Hash'
          ),
          React.createElement(
            styled.p`
              font-size: 0.9rem;
              color: #666666;
              margin-bottom: 1.5rem;
            `,
            null,
            'Paste the SHA-256 hash of your document to verify if it has been timestamped on our blockchain.'
          ),
          React.createElement(
            styled.div`
              display: flex;
              gap: 1rem;
              
              @media (max-width: 768px) {
                flex-direction: column;
              }
            `,
            null,
            React.createElement(
              styled.input`
                flex: 1;
                padding: 0.875rem 1rem;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                font-size: 1rem;
                transition: all 0.2s ease;
                font-family: monospace;
                
                &:focus {
                  border-color: #673AB7;
                  box-shadow: 0 0 0 3px rgba(103, 58, 183, 0.15);
                  outline: none;
                }
                
                &::placeholder {
                  color: #bbbbbb;
                }
              `,
              {
                type: 'text',
                placeholder: 'e.g. 8a1f9a8b0c3d...',
                value: documentHash,
                onChange: (e) => setDocumentHash(e.target.value),
              }
            ),
            React.createElement(
              styled.button`
                background-color: #FFC107;
                color: #333333;
                font-weight: 600;
                padding: 0.875rem 1.5rem;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.2s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                min-width: 150px;
                
                &:hover {
                  background-color: #ffb300;
                  box-shadow: 0 4px 8px rgba(255, 193, 7, 0.3);
                  transform: translateY(-1px);
                }
                
                &:active {
                  transform: translateY(0);
                  box-shadow: 0 2px 4px rgba(255, 193, 7, 0.3);
                }
                
                @media (max-width: 768px) {
                  width: 100%;
                }
              `,
              {
                onClick: validateDocument,
                disabled: isLoading,
              },
              isLoading ? 'Verifying...' : 'Verify Document'
            )
          ),
          error && React.createElement(
            styled.div`
              margin-top: 1rem;
              color: #d32f2f;
              font-size: 0.9rem;
              background-color: #ffebee;
              padding: 0.75rem 1rem;
              border-radius: 4px;
              border-left: 3px solid #d32f2f;
            `,
            null,
            error
          )
        ),
        isValid !== null && React.createElement(
          styled.div`
            border-top: 1px solid #eeeeee;
            padding-top: 2rem;
            transition: all 0.3s ease;
            opacity: ${animateResult ? '0.7' : '1'};
            transform: ${animateResult ? 'scale(0.98)' : 'scale(1)'};
          `,
          null,
          React.createElement(
            styled.div`
              display: flex;
              align-items: center;
              margin-bottom: 1.5rem;
            `,
            null,
            React.createElement(
              styled.div`
                width: 48px;
                height: 48px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 1rem;
                background-color: ${isValid ? '#8BC34A' : '#f44336'};
                color: #ffffff;
                font-size: 1.5rem;
              `,
              null,
              isValid ? '✓' : '✗'
            ),
            React.createElement(
              styled.div`
                flex: 1;
              `,
              null,
              React.createElement(
                styled.h3`
                  font-size: 1.25rem;
                  font-weight: 700;
                  color: ${isValid ? '#558b2f' : '#c62828'};
                  margin: 0 0 0.25rem 0;
                `,
                null,
                isValid ? 'Document Verified' : 'Document Not Found'
              ),
              React.createElement(
                styled.p`
                  font-size: 0.9rem;
                  color: #666666;
                  margin: 0;
                `,
                null,
                isValid 
                  ? 'This document has been timestamped on the blockchain.'
                  : 'This document has not been timestamped or the hash is incorrect.'
              )
            )
          ),
          isValid && React.createElement(
            styled.div`
              background-color: #f8f9fa;
              border-radius: 8px;
              padding: 1.5rem;
            `,
            null,
            React.createElement(
              styled.h4`
                font-size: 1rem;
                font-weight: 600;
                color: #333333;
                margin: 0 0 1rem 0;
              `,
              null,
              'Timestamp Information'
            ),
            React.createElement(
              styled.div`
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 1rem;
                
                @media (max-width: 600px) {
                  grid-template-columns: 1fr;
                }
              `,
              null,
              React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                `,
                null,
                React.createElement(
                  styled.span`
                    font-size: 0.8rem;
                    color: #888888;
                    margin-bottom: 0.25rem;
                  `,
                  null,
                  'Timestamp Date'
                ),
                React.createElement(
                  styled.span`
                    font-size: 0.95rem;
                    color: #333333;
                    font-weight: 500;
                  `,
                  null,
                  new Date().toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })
                )
              ),
              React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                `,
                null,
                React.createElement(
                  styled.span`
                    font-size: 0.8rem;
                    color: #888888;
                    margin-bottom: 0.25rem;
                  `,
                  null,
                  'Timestamp Time'
                ),
                React.createElement(
                  styled.span`
                    font-size: 0.95rem;
                    color: #333333;
                    font-weight: 500;
                  `,
                  null,
                  new Date().toLocaleTimeString('en-US')
                )
              ),
              React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                `,
                null,
                React.createElement(
                  styled.span`
                    font-size: 0.8rem;
                    color: #888888;
                    margin-bottom: 0.25rem;
                  `,
                  null,
                  'Block Number'
                ),
                React.createElement(
                  styled.span`
                    font-size: 0.95rem;
                    color: #333333;
                    font-weight: 500;
                  `,
                  null,
                  '14,325,678'
                )
              ),
              React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                `,
                null,
                React.createElement(
                  styled.span`
                    font-size: 0.8rem;
                    color: #888888;
                    margin-bottom: 0.25rem;
                  `,
                  null,
                  'Transaction Hash'
                ),
                React.createElement(
                  styled.span`
                    font-size: 0.95rem;
                    color: #333333;
                    font-weight: 500;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                  `,
                  null,
                  '0x3a1f9a8b0c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c9d8e7f'
                )
              )
            ),
            React.createElement(
              styled.div`
                margin-top: 1.5rem;
                display: flex;
                gap: 1rem;
                
                @media (max-width: 600px) {
                  flex-direction: column;
                }
              `,
              null,
              React.createElement(
                styled.button`
                  background-color: #673AB7;
                  color: #ffffff;
                  font-weight: 500;
                  padding: 0.75rem 1.25rem;
                  border: none;
                  border-radius: 6px;
                  cursor: pointer;
                  transition: all 0.2s ease;
                  flex: 1;
                  
                  &:hover {
                    background-color: #5e35b1;
                    box-shadow: 0 2px 5px rgba(103, 58, 183, 0.3);
                  }
                `,
                null,
                'View on Explorer'
              ),
              React.createElement(
                styled.button`
                  background-color: #f5f5f5;
                  color: #333333;
                  font-weight: 500;
                  padding: 0.75rem 1.25rem;
                  border: none;
                  border-radius: 6px;
                  cursor: pointer;
                  transition: all 0.2s ease;
                  flex: 1;
                  
                  &:hover {
                    background-color: #eeeeee;
                  }
                `,
                null,
                'Download Certificate'
              )
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          margin-top: 3rem;
          background-color: #f0f4f8;
          border-radius: 12px;
          padding: 2rem;
          
          @media (max-width: 768px) {
            padding: 1.5rem;
          }
        `,
        null,
        React.createElement(
          styled.h3`
            font-size: 1.25rem;
            font-weight: 700;
            color: #333333;
            margin-bottom: 1rem;
          `,
          null,
          'How Document Verification Works'
        ),
        React.createElement(
          styled.div`
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5rem;
            
            @media (max-width: 900px) {
              grid-template-columns: repeat(2, 1fr);
            }
            
            @media (max-width: 600px) {
              grid-template-columns: 1fr;
            }
          `,
          null,
          React.createElement(
            styled.div`
              background-color: #ffffff;
              border-radius: 8px;
              padding: 1.5rem;
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
              transition: transform 0.2s ease;
              
              &:hover {
                transform: translateY(-5px);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
              }
            `,
            null,
            React.createElement(
              styled.div`
                width: 40px;
                height: 40px;
                border-radius: 8px;
                background-color: #FFC107;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 1rem;
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: bold;
                `,
                null,
                '1'
              )
            ),
            React.createElement(
              styled.h4`
                font-size: 1rem;
                font-weight: 600;
                color: #333333;
                margin-bottom: 0.5rem;
              `,
              null,
              'Hash Generation'
            ),
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                line-height: 1.5;
              `,
              null,
              'Documents are processed through SHA-256 algorithm to generate a unique fingerprint that represents the document content.'
            )
          ),
          React.createElement(
            styled.div`
              background-color: #ffffff;
              border-radius: 8px;
              padding: 1.5rem;
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
              transition: transform 0.2s ease;
              
              &:hover {
                transform: translateY(-5px);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
              }
            `,
            null,
            React.createElement(
              styled.div`
                width: 40px;
                height: 40px;
                border-radius: 8px;
                background-color: #8BC34A;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 1rem;
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: bold;
                `,
                null,
                '2'
              )
            ),
            React.createElement(
              styled.h4`
                font-size: 1rem;
                font-weight: 600;
                color: #333333;
                margin-bottom: 0.5rem;
              `,
              null,
              'Blockchain Storage'
            ),
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                line-height: 1.5;
              `,
              null,
              'The document hash is stored on the blockchain with a timestamp, creating an immutable record of the document at that point in time.'
            )
          ),
          React.createElement(
            styled.div`
              background-color: #ffffff;
              border-radius: 8px;
              padding: 1.5rem;
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
              transition: transform 0.2s ease;
              
              &:hover {
                transform: translateY(-5px);
                box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
              }
            `,
            null,
            React.createElement(
              styled.div`
                width: 40px;
                height: 40px;
                border-radius: 8px;
                background-color: #673AB7;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 1rem;
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: bold;
                `,
                null,
                '3'
              )
            ),
            React.createElement(
              styled.h4`
                font-size: 1rem;
                font-weight: 600;
                color: #333333;
                margin-bottom: 0.5rem;
              `,
              null,
              'Verification Process'
            ),
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                line-height: 1.5;
              `,
              null,
              'During verification, the provided hash is compared with blockchain records to confirm authenticity and retrieve timestamp information.'
            )
          )
        )
      )
    ),
    React.createElement(
      styled.footer`
        background-color: #ffffff;
        padding: 2rem;
        border-top: 1px solid #eeeeee;
        text-align: center;
      `,
      null,
      React.createElement(
        styled.div`
          max-width: 1200px;
          margin: 0 auto;
        `,
        null,
        React.createElement(
          styled.p`
            color: #666666;
            font-size: 0.9rem;
            margin-bottom: 1rem;
          `,
          null,
          '© 2023 Document Timestamping Service. All rights reserved.'
        ),
        React.createElement(
          styled.div`
            display: flex;
            justify-content: center;
            gap: 1.5rem;
            
            @media (max-width: 600px) {
              flex-direction: column;
              gap: 0.5rem;
            }
          `,
          null,
          React.createElement(
            styled.a`
              color: #673AB7;
              text-decoration: none;
              font-size: 0.9rem;
              transition: color 0.2s ease;
              
              &:hover {
                color: #5e35b1;
                text-decoration: underline;
              }
            `,
            { href: '#' },
            'Terms of Service'
          ),
          React.createElement(
            styled.a`
              color: #673AB7;
              text-decoration: none;
              font-size: 0.9rem;
              transition: color 0.2s ease;
              
              &:hover {
                color: #5e35b1;
                text-decoration: underline;
              }
            `,
            { href: '#' },
            'Privacy Policy'
          ),
          React.createElement(
            styled.a`
              color: #673AB7;
              text-decoration: none;
              font-size: 0.9rem;
              transition: color 0.2s ease;
              
              &:hover {
                color: #5e35b1;
                text-decoration: underline;
              }
            `,
            { href: '#' },
            'Contact Support'
          )
        )
      )
    )
  );
}