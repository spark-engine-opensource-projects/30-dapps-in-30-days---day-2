'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function HeroSection() {
  return React.createElement(
    styled.section`
      background: linear-gradient(135deg, #f9f9f9 0%, #f0f0f0 100%);
      padding: 4rem 2rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 80vh;
      position: relative;
      overflow: hidden;
      
      @media (max-width: 768px) {
        padding: 3rem 1.5rem;
        min-height: auto;
      }
    `,
    null,
    React.createElement(
      styled.div`
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle at top right, rgba(103, 58, 183, 0.05), transparent 60%),
                    radial-gradient(circle at bottom left, rgba(255, 193, 7, 0.05), transparent 60%);
        z-index: 0;
      `,
      null
    ),
    React.createElement(
      styled.div`
        max-width: 1200px;
        width: 100%;
        z-index: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
      `,
      null,
      React.createElement(
        styled.h1`
          font-size: 3.5rem;
          font-weight: 800;
          color: #2d2d2d;
          margin-bottom: 1.5rem;
          line-height: 1.2;
          letter-spacing: -0.02em;
          
          span {
            color: #673AB7;
            position: relative;
            
            &::after {
              content: '';
              position: absolute;
              bottom: 0.1em;
              left: 0;
              width: 100%;
              height: 0.2em;
              background-color: #FFC107;
              z-index: -1;
              opacity: 0.3;
            }
          }
          
          @media (max-width: 768px) {
            font-size: 2.5rem;
          }
          
          @media (max-width: 480px) {
            font-size: 2rem;
          }
        `,
        null,
        'Secure Document Timestamps with ',
        React.createElement('span', null, 'Blockchain')
      ),
      React.createElement(
        styled.h2`
          font-size: 1.5rem;
          font-weight: 400;
          color: #5a5a5a;
          margin-bottom: 2.5rem;
          max-width: 700px;
          line-height: 1.6;
          
          @media (max-width: 768px) {
            font-size: 1.25rem;
            margin-bottom: 2rem;
          }
        `,
        null,
        'Permanently prove when your documents existed with tamper-proof timestamps. Protect your intellectual property with military-grade cryptography.'
      ),
      React.createElement(
        styled.div`
          display: flex;
          gap: 1.5rem;
          margin-bottom: 4rem;
          
          @media (max-width: 640px) {
            flex-direction: column;
            width: 100%;
            gap: 1rem;
          }
        `,
        null,
        React.createElement(
          styled.button`
            background-color: #FFC107;
            color: #333333;
            font-weight: 600;
            font-size: 1.125rem;
            padding: 1rem 2.5rem;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08);
            
            &:hover {
              background-color: #FFB300;
              transform: translateY(-2px);
              box-shadow: 0 7px 14px rgba(0, 0, 0, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08);
            }
            
            &:active {
              transform: translateY(1px);
              box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            
            @media (max-width: 640px) {
              width: 100%;
            }
          `,
          { onClick: () => window.location.href = '/register' },
          'Get Started Free'
        ),
        React.createElement(
          styled.button`
            background-color: transparent;
            color: #673AB7;
            font-weight: 600;
            font-size: 1.125rem;
            padding: 1rem 2.5rem;
            border-radius: 8px;
            border: 2px solid #673AB7;
            cursor: pointer;
            transition: all 0.3s ease;
            
            &:hover {
              background-color: rgba(103, 58, 183, 0.05);
            }
            
            @media (max-width: 640px) {
              width: 100%;
            }
          `,
          { onClick: () => window.location.href = '/learn-more' },
          'Learn More'
        )
      ),
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
          align-items: center;
          margin-top: 2rem;
        `,
        null,
        React.createElement(
          styled.p`
            font-size: 1rem;
            color: #777777;
            margin-bottom: 1.5rem;
            font-weight: 500;
          `,
          null,
          'TRUSTED BY THOUSANDS OF ORGANIZATIONS'
        ),
        React.createElement(
          styled.div`
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 2.5rem;
            max-width: 900px;
            
            @media (max-width: 768px) {
              gap: 2rem;
            }
            
            @media (max-width: 480px) {
              gap: 1.5rem;
            }
          `,
          null,
          [1, 2, 3, 4, 5].map((i) => 
            React.createElement(
              styled.div`
                opacity: 0.7;
                filter: grayscale(100%);
                transition: all 0.3s ease;
                height: 2.5rem;
                width: 7.5rem;
                background-color: #e0e0e0;
                border-radius: 4px;
                
                &:hover {
                  opacity: 0.9;
                  filter: grayscale(0%);
                }
              `,
              { key: i }
            )
          )
        )
      )
    ),
    React.createElement(
      styled.div`
        margin-top: 3.5rem;
        display: flex;
        gap: 2rem;
        justify-content: center;
        flex-wrap: wrap;
        max-width: 1000px;
        z-index: 1;
        
        @media (max-width: 768px) {
          gap: 1.5rem;
        }
      `,
      null,
      [
        { icon: '🔒', title: 'Secure', description: 'Military-grade encryption' },
        { icon: '⚡', title: 'Fast', description: 'Timestamps in seconds' },
        { icon: '📄', title: 'Verifiable', description: 'Court-admissible proof' },
        { icon: '🔗', title: 'Blockchain', description: 'Immutable records' }
      ].map((item, i) => 
        React.createElement(
          styled.div`
            background-color: #ffffff;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 200px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            
            &:hover {
              transform: translateY(-5px);
              box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            }
            
            @media (max-width: 768px) {
              width: calc(50% - 1rem);
              padding: 1.25rem;
            }
            
            @media (max-width: 480px) {
              width: 100%;
            }
          `,
          { key: i },
          React.createElement(
            styled.div`
              font-size: 2.5rem;
              margin-bottom: 1rem;
            `,
            null,
            item.icon
          ),
          React.createElement(
            styled.h3`
              font-size: 1.25rem;
              font-weight: 600;
              color: #333333;
              margin-bottom: 0.5rem;
            `,
            null,
            item.title
          ),
          React.createElement(
            styled.p`
              font-size: 0.875rem;
              color: #666666;
              text-align: center;
            `,
            null,
            item.description
          )
        )
      )
    )
  );
}