'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  
  return React.createElement(
    styled.header`
      background-color: #ffffff;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      padding: 1rem 2rem;
      position: sticky;
      top: 0;
      z-index: 100;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: all 0.3s ease;
      
      @media (max-width: 768px) {
        padding: 1rem 1.5rem;
      }
    `,
    null,
    React.createElement(
      styled.div`
        display: flex;
        align-items: center;
        gap: 1rem;
      `,
      null,
      React.createElement(
        styled.div`
          display: flex;
          align-items: center;
        `,
        null,
        React.createElement(
          styled.svg`
            width: 40px;
            height: 40px;
            fill: #FFC107;
            
            @media (max-width: 768px) {
              width: 36px;
              height: 36px;
            }
          `,
          { 
            viewBox: '0 0 24 24',
            xmlns: 'http://www.w3.org/2000/svg'
          },
          React.createElement(
            'path',
            { 
              d: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z' 
            }
          )
        ),
        React.createElement(
          styled.h1`
            font-size: 1.5rem;
            font-weight: 700;
            color: #333333;
            margin-left: 0.5rem;
            letter-spacing: -0.01em;
            
            @media (max-width: 768px) {
              font-size: 1.25rem;
            }
            
            @media (max-width: 480px) {
              display: none;
            }
          `,
          null,
          'TimeStamp'
        )
      )
    ),
    React.createElement(
      styled.nav`
        display: flex;
        align-items: center;
        
        @media (max-width: 768px) {
          position: absolute;
          top: ${isMenuOpen ? '100%' : '-300%'};
          left: 0;
          right: 0;
          background-color: #ffffff;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          padding: 1.5rem;
          flex-direction: column;
          align-items: flex-start;
          gap: 1.25rem;
          transition: top 0.3s ease-in-out;
        }
      `,
      null,
      React.createElement(
        styled.ul`
          display: flex;
          list-style: none;
          gap: 2rem;
          margin: 0;
          padding: 0;
          
          @media (max-width: 768px) {
            flex-direction: column;
            gap: 1.25rem;
            width: 100%;
          }
        `,
        null,
        ['Home', 'Features', 'How It Works', 'Validate'].map(item => 
          React.createElement(
            styled.li`
              margin: 0;
              padding: 0;
            `,
            { key: item },
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-weight: 500;
                font-size: 1rem;
                padding: 0.5rem 0;
                position: relative;
                transition: color 0.2s ease;
                
                &:hover {
                  color: #673AB7;
                }
                
                &:after {
                  content: '';
                  position: absolute;
                  width: ${item === 'Home' ? '100%' : '0'};
                  height: 2px;
                  bottom: 0;
                  left: 0;
                  background-color: #FFC107;
                  transition: width 0.3s ease;
                }
                
                &:hover:after {
                  width: 100%;
                }
                
                @media (max-width: 768px) {
                  display: block;
                  padding: 0.5rem 0;
                  width: 100%;
                }
              `,
              { href: item === 'Home' ? '/' : `/${item.toLowerCase().replace(/\s+/g, '-')}` },
              item
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          display: flex;
          gap: 1rem;
          margin-left: 2rem;
          
          @media (max-width: 768px) {
            margin-left: 0;
            width: 100%;
            justify-content: space-between;
          }
        `,
        null,
        isLoggedIn ? 
          React.createElement(
            styled.button`
              background-color: transparent;
              color: #673AB7;
              border: 1px solid #673AB7;
              padding: 0.6rem 1.25rem;
              border-radius: 4px;
              font-weight: 500;
              cursor: pointer;
              transition: all 0.2s ease;
              
              &:hover {
                background-color: rgba(103, 58, 183, 0.1);
              }
              
              @media (max-width: 768px) {
                width: 100%;
              }
            `,
            { onClick: () => setIsLoggedIn(false) },
            'Logout'
          ) : 
          [
            React.createElement(
              styled.button`
                background-color: transparent;
                color: #673AB7;
                border: 1px solid #673AB7;
                padding: 0.6rem 1.25rem;
                border-radius: 4px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                
                &:hover {
                  background-color: rgba(103, 58, 183, 0.1);
                }
                
                @media (max-width: 768px) {
                  flex: 1;
                }
              `,
              { 
                key: 'login',
                onClick: () => setIsLoggedIn(true) 
              },
              'Login'
            ),
            React.createElement(
              styled.button`
                background-color: #FFC107;
                color: #333333;
                border: none;
                padding: 0.6rem 1.25rem;
                border-radius: 4px;
                font-weight: 500;
                cursor: pointer;
                box-shadow: 0 2px 4px rgba(255, 193, 7, 0.3);
                transition: all 0.2s ease;
                
                &:hover {
                  background-color: #ffb300;
                  transform: translateY(-1px);
                  box-shadow: 0 4px 8px rgba(255, 193, 7, 0.4);
                }
                
                &:active {
                  transform: translateY(0);
                  box-shadow: 0 2px 4px rgba(255, 193, 7, 0.3);
                }
                
                @media (max-width: 768px) {
                  flex: 1;
                }
              `,
              { key: 'register' },
              'Register'
            )
          ]
      )
    ),
    React.createElement(
      styled.button`
        display: none;
        background: none;
        border: none;
        cursor: pointer;
        padding: 0.5rem;
        
        @media (max-width: 768px) {
          display: block;
        }
      `,
      { onClick: () => setIsMenuOpen(!isMenuOpen) },
      React.createElement(
        styled.svg`
          width: 24px;
          height: 24px;
          fill: #333333;
        `,
        { 
          viewBox: '0 0 24 24',
          xmlns: 'http://www.w3.org/2000/svg'
        },
        isMenuOpen ?
          React.createElement(
            'path',
            { d: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z' }
          ) :
          React.createElement(
            'path',
            { d: 'M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z' }
          )
      )
    )
  );
}