'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function Footer() {
  return React.createElement(
    styled.footer`
      background-color: #FFFFFF;
      border-top: 1px solid #E0E0E0;
      padding: 3rem 2rem;
      color: #333333;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      
      @media (max-width: 768px) {
        padding: 2rem 1rem;
      }
    `,
    null,
    React.createElement(
      styled.div`
        max-width: 1200px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 2rem;
        
        @media (max-width: 992px) {
          grid-template-columns: repeat(2, 1fr);
        }
        
        @media (max-width: 576px) {
          grid-template-columns: 1fr;
        }
      `,
      null,
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
        `,
        null,
        React.createElement(
          styled.h3`
            color: #673AB7;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            position: relative;
            
            &:after {
              content: '';
              position: absolute;
              bottom: -0.5rem;
              left: 0;
              width: 2.5rem;
              height: 3px;
              background-color: #FFC107;
            }
          `,
          null,
          'About TimestampDocs'
        ),
        React.createElement(
          styled.p`
            font-size: 0.95rem;
            line-height: 1.6;
            color: #555555;
            margin-bottom: 1.5rem;
          `,
          null,
          'Secure document timestamping service providing blockchain-backed proof of existence for your important files.'
        ),
        React.createElement(
          styled.div`
            display: flex;
            gap: 1rem;
          `,
          null,
          React.createElement(
            styled.a`
              display: flex;
              align-items: center;
              justify-content: center;
              width: 2.5rem;
              height: 2.5rem;
              border-radius: 50%;
              background-color: #F5F5F5;
              color: #673AB7;
              transition: all 0.3s ease;
              
              &:hover {
                background-color: #673AB7;
                color: #FFFFFF;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(103, 58, 183, 0.2);
              }
            `,
            { href: '#', 'aria-label': 'Twitter' },
            'X'
          ),
          React.createElement(
            styled.a`
              display: flex;
              align-items: center;
              justify-content: center;
              width: 2.5rem;
              height: 2.5rem;
              border-radius: 50%;
              background-color: #F5F5F5;
              color: #673AB7;
              transition: all 0.3s ease;
              
              &:hover {
                background-color: #673AB7;
                color: #FFFFFF;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(103, 58, 183, 0.2);
              }
            `,
            { href: '#', 'aria-label': 'LinkedIn' },
            'in'
          ),
          React.createElement(
            styled.a`
              display: flex;
              align-items: center;
              justify-content: center;
              width: 2.5rem;
              height: 2.5rem;
              border-radius: 50%;
              background-color: #F5F5F5;
              color: #673AB7;
              transition: all 0.3s ease;
              
              &:hover {
                background-color: #673AB7;
                color: #FFFFFF;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(103, 58, 183, 0.2);
              }
            `,
            { href: '#', 'aria-label': 'GitHub' },
            'G'
          )
        )
      ),
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
        `,
        null,
        React.createElement(
          styled.h3`
            color: #673AB7;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            position: relative;
            
            &:after {
              content: '';
              position: absolute;
              bottom: -0.5rem;
              left: 0;
              width: 2.5rem;
              height: 3px;
              background-color: #FFC107;
            }
          `,
          null,
          'Quick Links'
        ),
        React.createElement(
          styled.ul`
            list-style: none;
            padding: 0;
            margin: 0;
          `,
          null,
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'How It Works'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'Pricing'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'FAQ'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'Support'
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
        `,
        null,
        React.createElement(
          styled.h3`
            color: #673AB7;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            position: relative;
            
            &:after {
              content: '';
              position: absolute;
              bottom: -0.5rem;
              left: 0;
              width: 2.5rem;
              height: 3px;
              background-color: #FFC107;
            }
          `,
          null,
          'Legal'
        ),
        React.createElement(
          styled.ul`
            list-style: none;
            padding: 0;
            margin: 0;
          `,
          null,
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'Privacy Policy'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'Terms of Service'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'Cookie Policy'
            )
          ),
          React.createElement(
            styled.li`
              margin-bottom: 0.75rem;
            `,
            null,
            React.createElement(
              styled.a`
                color: #555555;
                text-decoration: none;
                font-size: 0.95rem;
                display: inline-flex;
                align-items: center;
                transition: color 0.2s ease, transform 0.2s ease;
                
                &:before {
                  content: '→';
                  margin-right: 0.5rem;
                  color: #8BC34A;
                  transition: transform 0.2s ease;
                }
                
                &:hover {
                  color: #673AB7;
                  transform: translateX(3px);
                  
                  &:before {
                    transform: translateX(2px);
                  }
                }
              `,
              { href: '#' },
              'GDPR Compliance'
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          display: flex;
          flex-direction: column;
        `,
        null,
        React.createElement(
          styled.h3`
            color: #673AB7;
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
            position: relative;
            
            &:after {
              content: '';
              position: absolute;
              bottom: -0.5rem;
              left: 0;
              width: 2.5rem;
              height: 3px;
              background-color: #FFC107;
            }
          `,
          null,
          'Contact Us'
        ),
        React.createElement(
          styled.div`
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
          `,
          null,
          React.createElement(
            styled.div`
              min-width: 2rem;
              height: 2rem;
              border-radius: 50%;
              background-color: #F5F5F5;
              display: flex;
              align-items: center;
              justify-content: center;
              margin-right: 1rem;
              color: #673AB7;
            `,
            null,
            '✉'
          ),
          React.createElement(
            styled.a`
              color: #555555;
              text-decoration: none;
              font-size: 0.95rem;
              transition: color 0.2s ease;
              
              &:hover {
                color: #673AB7;
              }
            `,
            { href: 'mailto:info@timestampdocs.com' },
            'info@timestampdocs.com'
          )
        ),
        React.createElement(
          styled.div`
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
          `,
          null,
          React.createElement(
            styled.div`
              min-width: 2rem;
              height: 2rem;
              border-radius: 50%;
              background-color: #F5F5F5;
              display: flex;
              align-items: center;
              justify-content: center;
              margin-right: 1rem;
              color: #673AB7;
            `,
            null,
            '☎'
          ),
          React.createElement(
            styled.a`
              color: #555555;
              text-decoration: none;
              font-size: 0.95rem;
              transition: color 0.2s ease;
              
              &:hover {
                color: #673AB7;
              }
            `,
            { href: 'tel:+11234567890' },
            '+1 (123) 456-7890'
          )
        ),
        React.createElement(
          styled.div`
            margin-top: 1.5rem;
          `,
          null,
          React.createElement(
            styled.h4`
              font-size: 1rem;
              font-weight: 600;
              color: #444444;
              margin-bottom: 1rem;
            `,
            null,
            'Subscribe to Our Newsletter'
          ),
          React.createElement(
            styled.div`
              display: flex;
              
              @media (max-width: 576px) {
                flex-direction: column;
              }
            `,
            null,
            React.createElement(
              styled.input`
                flex: 1;
                padding: 0.75rem 1rem;
                border: 1px solid #E0E0E0;
                border-radius: 4px 0 0 4px;
                font-size: 0.9rem;
                outline: none;
                transition: border-color 0.2s ease, box-shadow 0.2s ease;
                
                &:focus {
                  border-color: #673AB7;
                  box-shadow: 0 0 0 3px rgba(103, 58, 183, 0.1);
                }
                
                @media (max-width: 576px) {
                  border-radius: 4px;
                  margin-bottom: 0.5rem;
                }
              `,
              { type: 'email', placeholder: 'Your email address' }
            ),
            React.createElement(
              styled.button`
                background-color: #FFC107;
                color: #333333;
                font-weight: 600;
                padding: 0.75rem 1.25rem;
                border: none;
                border-radius: 0 4px 4px 0;
                cursor: pointer;
                transition: background-color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease;
                
                &:hover {
                  background-color: #FFCA28;
                  transform: translateY(-2px);
                  box-shadow: 0 4px 8px rgba(255, 193, 7, 0.2);
                }
                
                &:active {
                  transform: translateY(0);
                  box-shadow: none;
                }
                
                @media (max-width: 576px) {
                  border-radius: 4px;
                  width: 100%;
                }
              `,
              null,
              'Subscribe'
            )
          )
        )
      )
    ),
    React.createElement(
      styled.div`
        max-width: 1200px;
        margin: 3rem auto 0;
        padding-top: 2rem;
        border-top: 1px solid #E0E0E0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        
        @media (max-width: 768px) {
          flex-direction: column;
          gap: 1rem;
          text-align: center;
        }
      `,
      null,
      React.createElement(
        styled.p`
          color: #777777;
          font-size: 0.9rem;
        `,
        null,
        '© 2023 TimestampDocs. All rights reserved.'
      ),
      React.createElement(
        styled.div`
          display: flex;
          gap: 1.5rem;
          
          @media (max-width: 768px) {
            margin-top: 0.5rem;
          }
        `,
        null,
        React.createElement(
          styled.a`
            color: #777777;
            font-size: 0.9rem;
            text-decoration: none;
            transition: color 0.2s ease;
            
            &:hover {
              color: #673AB7;
            }
          `,
          { href: '#' },
          'Sitemap'
        ),
        React.createElement(
          styled.a`
            color: #777777;
            font-size: 0.9rem;
            text-decoration: none;
            transition: color 0.2s ease;
            
            &:hover {
              color: #673AB7;
            }
          `,
          { href: '#' },
          'Accessibility'
        ),
        React.createElement(
          styled.a`
            color: #777777;
            font-size: 0.9rem;
            text-decoration: none;
            transition: color 0.2s ease;
            
            &:hover {
              color: #673AB7;
            }
          `,
          { href: '#' },
          'Security'
        )
      )
    )
  );
}