'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function RegisterDocument() {
  const [file, setFile] = React.useState(null);
  const [documentName, setDocumentName] = React.useState('');
  const [documentDescription, setDocumentDescription] = React.useState('');
  const [documentHash, setDocumentHash] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [isSuccess, setIsSuccess] = React.useState(false);
  const [error, setError] = React.useState('');
  const [uploadProgress, setUploadProgress] = React.useState(0);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      calculateHash(selectedFile);
    }
  };

  const calculateHash = (file) => {
    setUploadProgress(0);
    const reader = new FileReader();
    
    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const progress = Math.round((event.loaded / event.total) * 50);
        setUploadProgress(progress);
      }
    };
    
    reader.onload = async (event) => {
      try {
        setUploadProgress(50);
        const buffer = event.target.result;
        const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        setDocumentHash(hashHex);
        setUploadProgress(100);
      } catch (err) {
        setError('Error calculating document hash');
        setUploadProgress(0);
      }
    };
    
    reader.onerror = () => {
      setError('Error reading file');
      setUploadProgress(0);
    };
    
    reader.readAsArrayBuffer(file);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    if (!documentHash || !documentName) {
      setError('Please upload a document and provide a name');
      return;
    }
    
    setIsSubmitting(true);
    setError('');
    
    try {
      // Simulate blockchain interaction
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In a real implementation, this would call the smart contract
      // const contract = new web3.eth.Contract(ABI, contractAddress);
      // await contract.methods.registerDocument(documentHash).send({ from: account });
      
      setIsSuccess(true);
      setDocumentName('');
      setDocumentDescription('');
      setFile(null);
      setDocumentHash('');
    } catch (err) {
      setError('Failed to register document on blockchain');
    } finally {
      setIsSubmitting(false);
    }
  };

  return React.createElement(
    styled.div`
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      background-color: #fafafa;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    `,
    null,
    React.createElement(
      styled.header`
        background-color: #ffffff;
        padding: 1.5rem 2rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 3px solid #FFC107;
      `,
      null,
      React.createElement(
        styled.h1`
          font-size: 1.5rem;
          font-weight: 700;
          color: #333333;
          margin: 0;
          display: flex;
          align-items: center;
          
          &:before {
            content: '';
            display: inline-block;
            width: 24px;
            height: 24px;
            background-color: #FFC107;
            margin-right: 12px;
            border-radius: 4px;
          }
          
          @media (min-width: 768px) {
            font-size: 1.75rem;
          }
        `,
        null,
        'Document Timestamping'
      ),
      React.createElement(
        styled.div`
          display: flex;
          align-items: center;
        `,
        null,
        React.createElement(
          styled.button`
            background-color: #673AB7;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            
            &:hover {
              background-color: #5e35b1;
              box-shadow: 0 2px 8px rgba(103, 58, 183, 0.4);
            }
            
            @media (min-width: 768px) {
              padding: 0.75rem 1.25rem;
              font-size: 1rem;
            }
          `,
          null,
          'Help'
        )
      )
    ),
    React.createElement(
      styled.main`
        flex: 1;
        padding: 2rem;
        max-width: 1200px;
        margin: 0 auto;
        width: 100%;
        
        @media (min-width: 768px) {
          padding: 3rem;
        }
      `,
      null,
      React.createElement(
        styled.div`
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
          overflow: hidden;
        `,
        null,
        React.createElement(
          styled.div`
            background-color: #FFC107;
            padding: 1.5rem 2rem;
            border-bottom: 1px solid #f0f0f0;
          `,
          null,
          React.createElement(
            styled.h2`
              color: #333333;
              margin: 0;
              font-size: 1.5rem;
              font-weight: 600;
            `,
            null,
            'Register New Document'
          ),
          React.createElement(
            styled.p`
              color: #555555;
              margin: 0.5rem 0 0;
              font-size: 1rem;
              line-height: 1.5;
            `,
            null,
            'Securely timestamp your document on the blockchain for immutable proof of existence.'
          )
        ),
        React.createElement(
          styled.form`
            padding: 2rem;
            
            @media (min-width: 768px) {
              padding: 2.5rem;
            }
          `,
          { onSubmit: handleSubmit },
          React.createElement(
            styled.div`
              margin-bottom: 2rem;
            `,
            null,
            React.createElement(
              styled.label`
                display: block;
                font-weight: 600;
                margin-bottom: 0.75rem;
                color: #333333;
                font-size: 1rem;
              `,
              null,
              'Upload Document'
            ),
            React.createElement(
              styled.div`
                border: 2px dashed ${file ? '#8BC34A' : '#e0e0e0'};
                border-radius: 6px;
                padding: 2rem;
                text-align: center;
                transition: all 0.2s ease;
                background-color: ${file ? '#f1f8e9' : '#fafafa'};
                cursor: pointer;
                position: relative;
                overflow: hidden;
                
                &:hover {
                  border-color: #FFC107;
                  background-color: #fffde7;
                }
              `,
              { onClick: () => document.getElementById('file-upload').click() },
              React.createElement(
                'input',
                {
                  type: 'file',
                  id: 'file-upload',
                  style: { display: 'none' },
                  onChange: handleFileChange,
                  accept: '.pdf,.doc,.docx,.txt,.jpg,.jpeg,.png'
                }
              ),
              file ? React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                `,
                null,
                React.createElement(
                  styled.div`
                    width: 48px;
                    height: 48px;
                    background-color: #8BC34A;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-bottom: 1rem;
                    color: #ffffff;
                    font-weight: bold;
                  `,
                  null,
                  '✓'
                ),
                React.createElement(
                  styled.span`
                    font-weight: 500;
                    font-size: 1rem;
                    color: #333333;
                    word-break: break-all;
                  `,
                  null,
                  file.name
                ),
                React.createElement(
                  styled.span`
                    margin-top: 0.5rem;
                    font-size: 0.875rem;
                    color: #666666;
                  `,
                  null,
                  `${(file.size / 1024 / 1024).toFixed(2)} MB`
                )
              ) : React.createElement(
                styled.div`
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                `,
                null,
                React.createElement(
                  styled.div`
                    width: 64px;
                    height: 64px;
                    background-color: #f5f5f5;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-bottom: 1rem;
                    color: #999999;
                    font-size: 1.5rem;
                  `,
                  null,
                  '+'
                ),
                React.createElement(
                  styled.span`
                    font-weight: 500;
                    font-size: 1rem;
                    color: #333333;
                  `,
                  null,
                  'Click to upload or drag and drop'
                ),
                React.createElement(
                  styled.span`
                    margin-top: 0.5rem;
                    font-size: 0.875rem;
                    color: #666666;
                  `,
                  null,
                  'PDF, DOC, TXT, JPG, PNG (Max 10MB)'
                )
              ),
              uploadProgress > 0 && uploadProgress < 100 && React.createElement(
                styled.div`
                  margin-top: 1rem;
                  width: 100%;
                `,
                null,
                React.createElement(
                  styled.div`
                    width: 100%;
                    height: 4px;
                    background-color: #e0e0e0;
                    border-radius: 2px;
                    overflow: hidden;
                  `,
                  null,
                  React.createElement(
                    styled.div`
                      height: 100%;
                      background-color: #FFC107;
                      width: ${uploadProgress}%;
                      transition: width 0.3s ease;
                    `,
                    null
                  )
                ),
                React.createElement(
                  styled.span`
                    display: block;
                    margin-top: 0.5rem;
                    font-size: 0.75rem;
                    color: #666666;
                  `,
                  null,
                  'Processing document...'
                )
              )
            )
          ),
          React.createElement(
            styled.div`
              margin-bottom: 2rem;
              display: grid;
              grid-template-columns: 1fr;
              gap: 1.5rem;
              
              @media (min-width: 768px) {
                grid-template-columns: 1fr 1fr;
              }
            `,
            null,
            React.createElement(
              styled.div`
              `,
              null,
              React.createElement(
                styled.label`
                  display: block;
                  font-weight: 600;
                  margin-bottom: 0.75rem;
                  color: #333333;
                  font-size: 1rem;
                `,
                { htmlFor: 'document-name' },
                'Document Name'
              ),
              React.createElement(
                styled.input`
                  width: 100%;
                  padding: 0.75rem 1rem;
                  border: 1px solid #e0e0e0;
                  border-radius: 4px;
                  font-size: 1rem;
                  transition: all 0.2s ease;
                  
                  &:focus {
                    outline: none;
                    border-color: #FFC107;
                    box-shadow: 0 0 0 3px rgba(255, 193, 7, 0.2);
                  }
                `,
                {
                  id: 'document-name',
                  type: 'text',
                  value: documentName,
                  onChange: (e) => setDocumentName(e.target.value),
                  placeholder: 'Enter document name',
                  required: true
                }
              )
            ),
            React.createElement(
              styled.div`
              `,
              null,
              React.createElement(
                styled.label`
                  display: block;
                  font-weight: 600;
                  margin-bottom: 0.75rem;
                  color: #333333;
                  font-size: 1rem;
                `,
                { htmlFor: 'document-description' },
                'Description (Optional)'
              ),
              React.createElement(
                styled.input`
                  width: 100%;
                  padding: 0.75rem 1rem;
                  border: 1px solid #e0e0e0;
                  border-radius: 4px;
                  font-size: 1rem;
                  transition: all 0.2s ease;
                  
                  &:focus {
                    outline: none;
                    border-color: #FFC107;
                    box-shadow: 0 0 0 3px rgba(255, 193, 7, 0.2);
                  }
                `,
                {
                  id: 'document-description',
                  type: 'text',
                  value: documentDescription,
                  onChange: (e) => setDocumentDescription(e.target.value),
                  placeholder: 'Brief description of the document'
                }
              )
            )
          ),
          documentHash && React.createElement(
            styled.div`
              margin-bottom: 2rem;
              padding: 1rem;
              background-color: #f3f3f3;
              border-radius: 4px;
            `,
            null,
            React.createElement(
              styled.label`
                display: block;
                font-weight: 600;
                margin-bottom: 0.5rem;
                color: #333333;
                font-size: 0.875rem;
              `,
              null,
              'Document Hash (SHA-256)'
            ),
            React.createElement(
              styled.div`
                font-family: monospace;
                word-break: break-all;
                font-size: 0.875rem;
                color: #555555;
                padding: 0.5rem 0;
              `,
              null,
              documentHash
            )
          ),
          error && React.createElement(
            styled.div`
              margin-bottom: 1.5rem;
              padding: 1rem;
              background-color: #fdecea;
              border-left: 4px solid #f44336;
              color: #d32f2f;
              border-radius: 4px;
            `,
            null,
            error
          ),
          isSuccess && React.createElement(
            styled.div`
              margin-bottom: 1.5rem;
              padding: 1rem;
              background-color: #e8f5e9;
              border-left: 4px solid #4caf50;
              color: #2e7d32;
              border-radius: 4px;
            `,
            null,
            'Document successfully registered on the blockchain!'
          ),
          React.createElement(
            styled.div`
              display: flex;
              justify-content: flex-end;
              gap: 1rem;
            `,
            null,
            React.createElement(
              styled.button`
                background-color: #f5f5f5;
                color: #333333;
                border: none;
                border-radius: 4px;
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                
                &:hover {
                  background-color: #e0e0e0;
                }
              `,
              { type: 'button', onClick: () => {
                setFile(null);
                setDocumentName('');
                setDocumentDescription('');
                setDocumentHash('');
                setError('');
                setIsSuccess(false);
              }},
              'Reset'
            ),
            React.createElement(
              styled.button`
                background-color: #FFC107;
                color: #333333;
                border: none;
                border-radius: 4px;
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                min-width: 160px;
                
                &:hover {
                  background-color: #ffb300;
                  box-shadow: 0 2px 8px rgba(255, 193, 7, 0.4);
                }
                
                &:disabled {
                  background-color: #e0e0e0;
                  color: #9e9e9e;
                  cursor: not-allowed;
                  box-shadow: none;
                }
              `,
              {
                type: 'submit',
                disabled: isSubmitting || !documentHash || !documentName
              },
              isSubmitting ? React.createElement(
                styled.div`
                  display: inline-block;
                  width: 20px;
                  height: 20px;
                  border: 3px solid rgba(255, 255, 255, 0.3);
                  border-radius: 50%;
                  border-top-color: #333333;
                  animation: spin 1s ease-in-out infinite;
                  margin-right: 0.5rem;
                  
                  @keyframes spin {
                    to { transform: rotate(360deg); }
                  }
                `,
                null
              ) : null,
              isSubmitting ? 'Processing...' : 'Register Document'
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          margin-top: 2rem;
          background-color: #ffffff;
          border-radius: 8px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
          padding: 1.5rem;
        `,
        null,
        React.createElement(
          styled.h3`
            color: #333333;
            margin: 0 0 1rem;
            font-size: 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            
            &:before {
              content: '';
              display: inline-block;
              width: 12px;
              height: 12px;
              background-color: #8BC34A;
              margin-right: 8px;
              border-radius: 50%;
            }
          `,
          null,
          'How Document Timestamping Works'
        ),
        React.createElement(
          styled.div`
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
            
            @media (min-width: 768px) {
              grid-template-columns: repeat(3, 1fr);
            }
          `,
          null,
          React.createElement(
            styled.div`
              padding: 1.25rem;
              border-radius: 6px;
              background-color: #f9f9f9;
              border-left: 3px solid #FFC107;
            `,
            null,
            React.createElement(
              styled.h4`
                margin: 0 0 0.75rem;
                color: #333333;
                font-size: 1rem;
                font-weight: 600;
              `,
              null,
              '1. Upload Document'
            ),
            React.createElement(
              styled.p`
                margin: 0;
                color: #666666;
                font-size: 0.875rem;
                line-height: 1.5;
              `,
              null,
              'We calculate a unique fingerprint (hash) of your document without storing the actual file.'
            )
          ),
          React.createElement(
            styled.div`
              padding: 1.25rem;
              border-radius: 6px;
              background-color: #f9f9f9;
              border-left: 3px solid #673AB7;
            `,
            null,
            React.createElement(
              styled.h4`
                margin: 0 0 0.75rem;
                color: #333333;
                font-size: 1rem;
                font-weight: 600;
              `,
              null,
              '2. Register on Blockchain'
            ),
            React.createElement(
              styled.p`
                margin: 0;
                color: #666666;
                font-size: 0.875rem;
                line-height: 1.5;
              `,
              null,
              'The document hash is permanently recorded on the blockchain with a timestamp.'
            )
          ),
          React.createElement(
            styled.div`
              padding: 1.25rem;
              border-radius: 6px;
              background-color: #f9f9f9;
              border-left: 3px solid #8BC34A;
            `,
            null,
            React.createElement(
              styled.h4`
                margin: 0 0 0.75rem;
                color: #333333;
                font-size: 1rem;
                font-weight: 600;
              `,
              null,
              '3. Verify Anytime'
            ),
            React.createElement(
              styled.p`
                margin: 0;
                color: #666666;
                font-size: 0.875rem;
                line-height: 1.5;
              `,
              null,
              'You can prove document existence and integrity at any future date using our verification tool.'
            )
          )
        )
      )
    ),
    React.createElement(
      styled.footer`
        background-color: #333333;
        color: #ffffff;
        padding: 2rem;
        text-align: center;
      `,
      null,
      React.createElement(
        styled.p`
          margin: 0;
          font-size: 0.875rem;
          opacity: 0.8;
        `,
        null,
        '© 2023 Document Timestamping Service. All rights reserved.'
      )
    )
  );
}