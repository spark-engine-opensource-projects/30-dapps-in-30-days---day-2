'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function HowItWorks() {
  return React.createElement(
    styled.section`
      padding: 4rem 2rem;
      background: linear-gradient(135deg, #ffffff 0%, #f9f9f9 100%);
      font-family: 'Inter', sans-serif;
      
      @media (max-width: 768px) {
        padding: 3rem 1.5rem;
      }
    `,
    null,
    React.createElement(
      styled.div`
        max-width: 1200px;
        margin: 0 auto;
      `,
      null,
      React.createElement(
        styled.header`
          text-align: center;
          margin-bottom: 3rem;
        `,
        null,
        React.createElement(
          styled.h1`
            font-size: 2.5rem;
            font-weight: 700;
            color: #333333;
            margin-bottom: 1rem;
            position: relative;
            display: inline-block;
            
            &:after {
              content: '';
              position: absolute;
              bottom: -0.5rem;
              left: 50%;
              transform: translateX(-50%);
              width: 80px;
              height: 4px;
              background-color: #FFC107;
              border-radius: 2px;
            }
            
            @media (max-width: 768px) {
              font-size: 2rem;
            }
          `,
          null,
          'How It Works'
        ),
        React.createElement(
          styled.p`
            font-size: 1.1rem;
            color: #666666;
            max-width: 700px;
            margin: 0 auto;
            line-height: 1.6;
          `,
          null,
          'Our document timestamping service provides a secure, blockchain-based method to prove the existence of your documents at a specific point in time.'
        )
      ),
      
      React.createElement(
        styled.div`
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2.5rem;
          margin-top: 3rem;
          
          @media (max-width: 768px) {
            grid-template-columns: 1fr;
            gap: 2rem;
          }
        `,
        null,
        
        // Step 1
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-5px);
              box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            }
            
            &:before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 4px;
              height: 100%;
              background-color: #FFC107;
            }
          `,
          null,
          React.createElement(
            styled.div`
              display: flex;
              align-items: center;
              margin-bottom: 1.5rem;
            `,
            null,
            React.createElement(
              styled.div`
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background-color: #FFC107;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 1rem;
                flex-shrink: 0;
                box-shadow: 0 4px 10px rgba(255, 193, 7, 0.3);
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: 700;
                  font-size: 1.2rem;
                `,
                null,
                '1'
              )
            ),
            React.createElement(
              styled.h3`
                font-size: 1.3rem;
                font-weight: 600;
                color: #333333;
                margin: 0;
              `,
              null,
              'Upload Your Document'
            )
          ),
          React.createElement(
            styled.p`
              color: #555555;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'Select and upload the document you want to timestamp. We accept various file formats including PDF, DOC, JPG, and more.'
          ),
          React.createElement(
            styled.div`
              background-color: #f9f9f9;
              border-radius: 8px;
              padding: 1rem;
              border-left: 3px solid #8BC34A;
            `,
            null,
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                margin: 0;
              `,
              null,
              'Your document remains private. We only calculate and store a unique fingerprint (hash) of your file.'
            )
          )
        ),
        
        // Step 2
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-5px);
              box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            }
            
            &:before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 4px;
              height: 100%;
              background-color: #8BC34A;
            }
          `,
          null,
          React.createElement(
            styled.div`
              display: flex;
              align-items: center;
              margin-bottom: 1.5rem;
            `,
            null,
            React.createElement(
              styled.div`
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background-color: #8BC34A;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 1rem;
                flex-shrink: 0;
                box-shadow: 0 4px 10px rgba(139, 195, 74, 0.3);
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: 700;
                  font-size: 1.2rem;
                `,
                null,
                '2'
              )
            ),
            React.createElement(
              styled.h3`
                font-size: 1.3rem;
                font-weight: 600;
                color: #333333;
                margin: 0;
              `,
              null,
              'Generate Document Hash'
            )
          ),
          React.createElement(
            styled.p`
              color: #555555;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'Our system creates a unique cryptographic hash of your document using SHA-256 algorithm. This hash serves as a digital fingerprint for your document.'
          ),
          React.createElement(
            styled.div`
              background-color: #f9f9f9;
              border-radius: 8px;
              padding: 1rem;
              border-left: 3px solid #673AB7;
            `,
            null,
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                font-family: monospace;
                margin: 0;
                word-break: break-all;
              `,
              null,
              'Example hash: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
            )
          )
        ),
        
        // Step 3
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-5px);
              box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            }
            
            &:before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 4px;
              height: 100%;
              background-color: #673AB7;
            }
          `,
          null,
          React.createElement(
            styled.div`
              display: flex;
              align-items: center;
              margin-bottom: 1.5rem;
            `,
            null,
            React.createElement(
              styled.div`
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background-color: #673AB7;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 1rem;
                flex-shrink: 0;
                box-shadow: 0 4px 10px rgba(103, 58, 183, 0.3);
              `,
              null,
              React.createElement(
                styled.span`
                  color: #ffffff;
                  font-weight: 700;
                  font-size: 1.2rem;
                `,
                null,
                '3'
              )
            ),
            React.createElement(
              styled.h3`
                font-size: 1.3rem;
                font-weight: 600;
                color: #333333;
                margin: 0;
              `,
              null,
              'Record on Blockchain'
            )
          ),
          React.createElement(
            styled.p`
              color: #555555;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'The document hash is permanently recorded on the blockchain with a timestamp. This creates an immutable record proving the document existed at that specific time.'
          ),
          React.createElement(
            styled.div`
              background-color: #f9f9f9;
              border-radius: 8px;
              padding: 1rem;
              border-left: 3px solid #FFC107;
            `,
            null,
            React.createElement(
              styled.p`
                font-size: 0.9rem;
                color: #666666;
                margin: 0;
              `,
              null,
              'Once recorded, the timestamp cannot be altered or tampered with, providing irrefutable proof of your document\'s existence.'
            )
          )
        )
      ),
      
      // Technical Explanation Section
      React.createElement(
        styled.div`
          margin-top: 5rem;
          background-color: #ffffff;
          border-radius: 12px;
          padding: 2.5rem;
          box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
          
          @media (max-width: 768px) {
            padding: 1.5rem;
          }
        `,
        null,
        React.createElement(
          styled.h2`
            font-size: 1.8rem;
            font-weight: 700;
            color: #333333;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            
            &:before {
              content: '';
              display: inline-block;
              width: 18px;
              height: 18px;
              background-color: #673AB7;
              margin-right: 0.75rem;
              border-radius: 4px;
            }
          `,
          null,
          'Technical Process Explained'
        ),
        React.createElement(
          styled.div`
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2.5rem;
            
            @media (max-width: 992px) {
              grid-template-columns: 1fr;
            }
          `,
          null,
          React.createElement(
            styled.div``,
            null,
            React.createElement(
              styled.h3`
                font-size: 1.2rem;
                font-weight: 600;
                color: #444444;
                margin-bottom: 1rem;
              `,
              null,
              'Cryptographic Hashing'
            ),
            React.createElement(
              styled.p`
                color: #555555;
                line-height: 1.7;
                margin-bottom: 1.5rem;
              `,
              null,
              'We use the SHA-256 cryptographic hash function to generate a unique, fixed-length string of characters that represents your document. Even the smallest change to your document will produce a completely different hash, ensuring the integrity of your timestamped document.'
            ),
            React.createElement(
              styled.h3`
                font-size: 1.2rem;
                font-weight: 600;
                color: #444444;
                margin-bottom: 1rem;
              `,
              null,
              'Blockchain Anchoring'
            ),
            React.createElement(
              styled.p`
                color: #555555;
                line-height: 1.7;
              `,
              null,
              'The document hash is anchored to the blockchain through a transaction that includes the hash and a timestamp. This creates a permanent, immutable record that can be independently verified by anyone, without requiring access to the original document.'
            )
          ),
          React.createElement(
            styled.div`
              background-color: #f9f9f9;
              border-radius: 10px;
              padding: 1.5rem;
              position: relative;
              overflow: hidden;
              
              &:before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 4px;
                background: linear-gradient(to right, #FFC107, #8BC34A, #673AB7);
              }
            `,
            null,
            React.createElement(
              styled.h3`
                font-size: 1.2rem;
                font-weight: 600;
                color: #444444;
                margin-bottom: 1rem;
              `,
              null,
              'Verification Process'
            ),
            React.createElement(
              styled.ol`
                color: #555555;
                padding-left: 1.5rem;
                
                & li {
                  margin-bottom: 1rem;
                  line-height: 1.6;
                }
                
                & li:last-child {
                  margin-bottom: 0;
                }
              `,
              null,
              React.createElement(
                'li',
                null,
                'Upload the document you want to verify'
              ),
              React.createElement(
                'li',
                null,
                'Our system calculates the document\'s hash'
              ),
              React.createElement(
                'li',
                null,
                'The system searches the blockchain for matching hash records'
              ),
              React.createElement(
                'li',
                null,
                'If found, we display the timestamp and blockchain transaction details'
              ),
              React.createElement(
                'li',
                null,
                'You can independently verify this information on any blockchain explorer'
              )
            )
          )
        )
      ),
      
      // Interactive Element
      React.createElement(
        styled.div`
          margin-top: 4rem;
          text-align: center;
        `,
        null,
        React.createElement(
          styled.h2`
            font-size: 1.6rem;
            font-weight: 700;
            color: #333333;
            margin-bottom: 1.5rem;
          `,
          null,
          'Ready to Timestamp Your Document?'
        ),
        React.createElement(
          styled.p`
            color: #555555;
            max-width: 600px;
            margin: 0 auto 2rem;
            line-height: 1.6;
          `,
          null,
          'Start securing your important documents with our blockchain timestamping service today.'
        ),
        React.createElement(
          styled.button`
            background-color: #FFC107;
            color: #333333;
            font-weight: 600;
            font-size: 1.1rem;
            padding: 0.8rem 2rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);
            position: relative;
            overflow: hidden;
            
            &:hover {
              background-color: #ffca28;
              transform: translateY(-2px);
              box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
            }
            
            &:active {
              transform: translateY(0);
              box-shadow: 0 2px 10px rgba(255, 193, 7, 0.3);
            }
            
            &:before {
              content: '';
              position: absolute;
              top: 0;
              left: -100%;
              width: 100%;
              height: 100%;
              background: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0) 0%,
                rgba(255, 255, 255, 0.2) 50%,
                rgba(255, 255, 255, 0) 100%
              );
              transition: left 0.7s ease;
            }
            
            &:hover:before {
              left: 100%;
            }
          `,
          null,
          'Get Started Now'
        )
      )
    )
  );
}