'use client';
import React from 'react';
import styled from 'styled-components';

      import { useSelector, useDispatch } from 'react-redux';
      import {
        setSignerConnection,
        setSignerInstance,
        setSignerChainId,
        connectSignerAction,
        disconnectSignerAction,
        updateSignerChainIdAction
      } from '../redux/actions';

    import {ethers} from 'ethers';
export default function ServiceFeatures() {
  return React.createElement(
    styled.section`
      padding: 5rem 2rem;
      background-color: #fafafa;
      position: relative;
      overflow: hidden;

      &::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, rgba(255, 193, 7, 0.05) 0%, rgba(103, 58, 183, 0.05) 100%);
        z-index: 0;
      }

      @media (max-width: 768px) {
        padding: 3rem 1.5rem;
      }
    `,
    null,
    React.createElement(
      styled.div`
        max-width: 1200px;
        margin: 0 auto;
        position: relative;
        z-index: 1;
      `,
      null,
      React.createElement(
        styled.div`
          text-align: center;
          margin-bottom: 4rem;
        `,
        null,
        React.createElement(
          styled.h2`
            font-size: 2.5rem;
            font-weight: 700;
            color: #333333;
            margin-bottom: 1rem;
            position: relative;
            display: inline-block;

            &::after {
              content: '';
              position: absolute;
              bottom: -0.75rem;
              left: 50%;
              transform: translateX(-50%);
              width: 80px;
              height: 4px;
              background: linear-gradient(to right, #FFC107, #673AB7);
              border-radius: 2px;
            }

            @media (max-width: 768px) {
              font-size: 2rem;
            }
          `,
          null,
          'Secure Document Timestamping'
        ),
        React.createElement(
          styled.p`
            font-size: 1.25rem;
            color: #555555;
            max-width: 800px;
            margin: 1.5rem auto 0;
            line-height: 1.6;
            
            @media (max-width: 768px) {
              font-size: 1.125rem;
            }
          `,
          null,
          'Our advanced platform provides tamper-proof verification with cutting-edge blockchain technology'
        )
      ),
      React.createElement(
        styled.div`
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 2rem;
          
          @media (max-width: 1024px) {
            grid-template-columns: repeat(2, 1fr);
          }
          
          @media (max-width: 640px) {
            grid-template-columns: 1fr;
          }
        `,
        null,
        // Feature Card 1
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2.5rem 2rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-8px);
              box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            }
            
            &::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 6px;
              height: 60%;
              background-color: #FFC107;
              border-top-left-radius: 12px;
              transform: scaleY(0);
              transform-origin: top;
              transition: transform 0.3s ease;
            }
            
            &:hover::before {
              transform: scaleY(1);
            }
          `,
          null,
          React.createElement(
            styled.div`
              width: 80px;
              height: 80px;
              border-radius: 50%;
              background-color: #FFF8E1;
              display: flex;
              align-items: center;
              justify-content: center;
              margin-bottom: 1.5rem;
              transition: background-color 0.3s ease;
              
              svg {
                transition: transform 0.3s ease;
              }
              
              &:hover {
                background-color: #FFF0C4;
                
                svg {
                  transform: scale(1.1);
                }
              }
            `,
            null,
            React.createElement(
              'svg',
              { 
                width: '40', 
                height: '40', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: '#FFC107', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('path', { d: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z' })
            )
          ),
          React.createElement(
            styled.h3`
              font-size: 1.5rem;
              font-weight: 600;
              color: #333333;
              margin-bottom: 1rem;
            `,
            null,
            'Military-Grade Security'
          ),
          React.createElement(
            styled.p`
              color: #666666;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'Your documents are protected with advanced encryption standards ensuring maximum security and privacy.'
          ),
          React.createElement(
            styled.a`
              display: inline-flex;
              align-items: center;
              color: #673AB7;
              font-weight: 500;
              text-decoration: none;
              transition: color 0.2s ease;
              
              &:hover {
                color: #FFC107;
              }
              
              svg {
                margin-left: 0.5rem;
                transition: transform 0.2s ease;
              }
              
              &:hover svg {
                transform: translateX(3px);
              }
            `,
            { href: '#' },
            'Learn more',
            React.createElement(
              'svg',
              { 
                width: '16', 
                height: '16', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: 'currentColor', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('line', { x1: '5', y1: '12', x2: '19', y2: '12' }),
              React.createElement('polyline', { points: '12 5 19 12 12 19' })
            )
          )
        ),
        // Feature Card 2
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2.5rem 2rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-8px);
              box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            }
            
            &::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 6px;
              height: 60%;
              background-color: #8BC34A;
              border-top-left-radius: 12px;
              transform: scaleY(0);
              transform-origin: top;
              transition: transform 0.3s ease;
            }
            
            &:hover::before {
              transform: scaleY(1);
            }
          `,
          null,
          React.createElement(
            styled.div`
              width: 80px;
              height: 80px;
              border-radius: 50%;
              background-color: #F1F8E9;
              display: flex;
              align-items: center;
              justify-content: center;
              margin-bottom: 1.5rem;
              transition: background-color 0.3s ease;
              
              svg {
                transition: transform 0.3s ease;
              }
              
              &:hover {
                background-color: #E8F5E9;
                
                svg {
                  transform: scale(1.1);
                }
              }
            `,
            null,
            React.createElement(
              'svg',
              { 
                width: '40', 
                height: '40', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: '#8BC34A', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('polyline', { points: '20 6 9 17 4 12' })
            )
          ),
          React.createElement(
            styled.h3`
              font-size: 1.5rem;
              font-weight: 600;
              color: #333333;
              margin-bottom: 1rem;
            `,
            null,
            'Blockchain Verification'
          ),
          React.createElement(
            styled.p`
              color: #666666;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'Immutable timestamps backed by decentralized blockchain technology provide tamper-proof verification.'
          ),
          React.createElement(
            styled.a`
              display: inline-flex;
              align-items: center;
              color: #673AB7;
              font-weight: 500;
              text-decoration: none;
              transition: color 0.2s ease;
              
              &:hover {
                color: #8BC34A;
              }
              
              svg {
                margin-left: 0.5rem;
                transition: transform 0.2s ease;
              }
              
              &:hover svg {
                transform: translateX(3px);
              }
            `,
            { href: '#' },
            'Learn more',
            React.createElement(
              'svg',
              { 
                width: '16', 
                height: '16', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: 'currentColor', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('line', { x1: '5', y1: '12', x2: '19', y2: '12' }),
              React.createElement('polyline', { points: '12 5 19 12 12 19' })
            )
          )
        ),
        // Feature Card 3
        React.createElement(
          styled.div`
            background-color: #ffffff;
            border-radius: 12px;
            padding: 2.5rem 2rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
            position: relative;
            overflow: hidden;
            
            &:hover {
              transform: translateY(-8px);
              box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
            }
            
            &::before {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 6px;
              height: 60%;
              background-color: #673AB7;
              border-top-left-radius: 12px;
              transform: scaleY(0);
              transform-origin: top;
              transition: transform 0.3s ease;
            }
            
            &:hover::before {
              transform: scaleY(1);
            }
          `,
          null,
          React.createElement(
            styled.div`
              width: 80px;
              height: 80px;
              border-radius: 50%;
              background-color: #EDE7F6;
              display: flex;
              align-items: center;
              justify-content: center;
              margin-bottom: 1.5rem;
              transition: background-color 0.3s ease;
              
              svg {
                transition: transform 0.3s ease;
              }
              
              &:hover {
                background-color: #E1D5F5;
                
                svg {
                  transform: scale(1.1);
                }
              }
            `,
            null,
            React.createElement(
              'svg',
              { 
                width: '40', 
                height: '40', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: '#673AB7', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('path', { d: 'M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z' }),
              React.createElement('polyline', { points: '13 2 13 9 20 9' })
            )
          ),
          React.createElement(
            styled.h3`
              font-size: 1.5rem;
              font-weight: 600;
              color: #333333;
              margin-bottom: 1rem;
            `,
            null,
            'Intuitive User Experience'
          ),
          React.createElement(
            styled.p`
              color: #666666;
              line-height: 1.6;
              margin-bottom: 1.5rem;
            `,
            null,
            'Our user-friendly interface makes document timestamping accessible to everyone, no technical expertise required.'
          ),
          React.createElement(
            styled.a`
              display: inline-flex;
              align-items: center;
              color: #673AB7;
              font-weight: 500;
              text-decoration: none;
              transition: color 0.2s ease;
              
              &:hover {
                color: #673AB7;
              }
              
              svg {
                margin-left: 0.5rem;
                transition: transform 0.2s ease;
              }
              
              &:hover svg {
                transform: translateX(3px);
              }
            `,
            { href: '#' },
            'Learn more',
            React.createElement(
              'svg',
              { 
                width: '16', 
                height: '16', 
                viewBox: '0 0 24 24', 
                fill: 'none', 
                stroke: 'currentColor', 
                strokeWidth: '2', 
                strokeLinecap: 'round', 
                strokeLinejoin: 'round' 
              },
              React.createElement('line', { x1: '5', y1: '12', x2: '19', y2: '12' }),
              React.createElement('polyline', { points: '12 5 19 12 12 19' })
            )
          )
        )
      ),
      React.createElement(
        styled.div`
          margin-top: 4rem;
          text-align: center;
        `,
        null,
        React.createElement(
          styled.button`
            background: linear-gradient(45deg, #673AB7, #8BC34A);
            color: #ffffff;
            font-size: 1.125rem;
            font-weight: 600;
            padding: 1rem 2.5rem;
            border-radius: 50px;
            border: none;
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 20px rgba(103, 58, 183, 0.3);
            position: relative;
            overflow: hidden;
            min-width: 200px;
            
            &:hover {
              transform: translateY(-3px);
              box-shadow: 0 8px 25px rgba(103, 58, 183, 0.4);
            }
            
            &:active {
              transform: translateY(-1px);
            }
            
            &::after {
              content: '';
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background: linear-gradient(45deg, rgba(255, 193, 7, 0.3), rgba(103, 58, 183, 0));
              opacity: 0;
              transition: opacity 0.3s ease;
            }
            
            &:hover::after {
              opacity: 1;
            }
            
            @media (max-width: 640px) {
              padding: 0.875rem 2rem;
              font-size: 1rem;
              min-width: 180px;
            }
          `,
          null,
          'Get Started Now'
        )
      )
    )
  );
}